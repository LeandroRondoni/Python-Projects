# Análise de Dados em Python - LabHacker Câmara dos Deputados

Jupyter notebooks criados durante o curso de análise de dados com Python disponibilizado pelo [LabHacker Câmara dos Deputados](http://labhackercd.leg.br/).

## Vídeos

* [Instalando o Anaconda](https://youtu.be/wiMVpFfxA0w)
* [Aula 01](https://youtu.be/W_Bz7M91R1Q)
* [Aula 02](https://youtu.be/2oZHg3HOtcY)
* [Aula 03](https://youtu.be/zpNtiJsJ7KY)
* [Aula 04](https://youtu.be/hyDvL_CzbX4)
